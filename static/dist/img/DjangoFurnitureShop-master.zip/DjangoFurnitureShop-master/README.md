# Django Furniture Shop
## Screenshots
![](./screenshot_furniture_shop.png)

## Details
My first Django E-commerce. It allows users to buy and sell products (furnitures for example). Every order is calculated and email with Invoice attached is sent to a customer. 

## Preview 
Preview of this app is currently possible on PythonAnywhere platform:
http://przemyslawsarnacki.pythonanywhere.com/